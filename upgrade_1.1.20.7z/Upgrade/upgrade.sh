#!/bin/sh

sync
sync
cp /root/* /media/mmcblk0p1/FWBackup/
cp /usr/lib/* /media/mmcblk0p1/FWBackup/usr/lib/
cp /etc/* /media/mmcblk0p1/FWBackup/etc/
cp /etc/rc.d/* /media/mmcblk0p1/FWBackup/etc/rc.d/
cp /etc/rc.d/init.d/* /media/mmcblk0p1/FWBackup/etc/rc.d/init.d/
cp /media/mmcblk1p1/zImage /media/mmcblk0p1/FWBackup/zImage
cp /media/mmcblk1p1/logo-7.bmp /media/mmcblk0p1/FWBackup/logo-7.bmp
sync
sync
sync


